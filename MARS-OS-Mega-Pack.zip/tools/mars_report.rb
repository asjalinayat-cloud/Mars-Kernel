#!/usr/bin/env ruby
# Generate a readable source-file report for the MARS project.
require "find"

root = File.expand_path(ARGV[0] || ".")
abort "Directory not found: #{root}" unless Dir.exist?(root)

files = []
Find.find(root) do |path|
  next if path == root
  if File.file?(path) && !path.split(File::SEPARATOR).any? { |part| part.start_with?(".") }
    files << path
  end
end

puts "MARS OS SOURCE REPORT"
puts "=" * 30
puts "Root: #{root}"
puts "Files: #{files.length}"
files.sort.each { |file| puts " - #{file.delete_prefix(root + File::SEPARATOR)}" }
