# Tiny base-R report: count source files by extension.
args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args) > 0) args[[1]] else "."
if (!dir.exists(root)) stop(paste("Directory not found:", root))

paths <- list.files(root, recursive = TRUE, full.names = TRUE,
                    all.files = FALSE, include.dirs = FALSE)
ext <- tools::file_ext(paths)
ext[ext == ""] <- "(no extension)"
counts <- sort(table(ext), decreasing = TRUE)

cat("MARS OS FILE METRICS\n")
cat("====================\n")
cat("Root:", normalizePath(root), "\n")
print(counts)
cat("Total files:", length(paths), "\n")
