#!/usr/bin/env python3
"""Print a small, dependency-free inventory of the MARS source tree."""
from pathlib import Path
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
if not root.is_dir():
    raise SystemExit(f"Not a directory: {root}")

extensions = {".c": "C", ".h": "C header", ".cpp": "C++",
              ".hpp": "C++ header", ".S": "Assembly", ".html": "HTML",
              ".css": "CSS", ".js": "JavaScript", ".py": "Python",
              ".rb": "Ruby", ".java": "Java", ".lisp": "Lisp", ".R": "R"}
counts = {}
for path in root.rglob("*"):
    if path.is_file() and not any(part.startswith(".") for part in path.parts):
        kind = extensions.get(path.suffix, "Other")
        counts[kind] = counts.get(kind, 0) + 1

print(f"MARS source inventory: {root}")
for kind, count in sorted(counts.items()):
    print(f"  {kind:14} {count:>4}")
print(f"  {'TOTAL':14} {sum(counts.values()):>4}")
