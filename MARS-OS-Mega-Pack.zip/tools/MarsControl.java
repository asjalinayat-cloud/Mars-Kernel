import java.nio.file.Files;
import java.nio.file.Path;

/** Host-side MARS helper. It checks the kernel artifact; it does not run the kernel. */
public final class MarsControl {
    private MarsControl() {}

    public static void main(String[] args) {
        String command = args.length == 0 ? "help" : args[0];
        switch (command) {
            case "status" -> {
                Path kernel = Path.of("mars.bin");
                System.out.println("MARS Control Center");
                System.out.println("Kernel artifact: " +
                    (Files.isRegularFile(kernel) ? "FOUND" : "NOT BUILT"));
                System.out.println("Architecture target: x86 / 32-bit");
            }
            case "help" -> {
                System.out.println("Usage: java MarsControl [status|help]");
                System.out.println("Run from the project root.");
            }
            default -> {
                System.err.println("Unknown command: " + command);
                System.exit(2);
            }
        }
    }
}
