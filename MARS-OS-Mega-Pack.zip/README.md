# MARS OS Mega Pack

A larger educational operating-system development workspace for **MARS OS**.
It combines a small bootable C/C++ kernel starter with companion tools and a
browser-based control panel written in HTML, CSS, and JavaScript.

## Languages included

- **C / C++** — bare-metal kernel and system layer.
- **HTML / CSS / JavaScript** — local project dashboard.
- **Shell** — build and QEMU launch scripts.
- **Python** — project inspection and image/boot metadata helper.
- **Ruby** — source inventory and project report.
- **Java** — command-line control-center utility.
- **Lisp** — example kernel configuration data.
- **R** — simple project metrics report.

Important: only C and C++ are compiled into the bare-metal kernel in this
starter. The other languages are companion tools, dashboard code, examples,
or host-side utilities. They are not all running inside the kernel. Adding
managed runtimes and interpreters to an OS requires substantial porting work.

## Requirements

For the kernel:
- Linux development environment
- `i686-elf-gcc`, `i686-elf-g++`
- NASM and GNU Make
- QEMU (`qemu-system-i386`)

For optional tools:
- Python 3
- Ruby
- Java 17+
- R
- Any modern browser

## Quick start

```sh
chmod +x scripts/*.sh
./scripts/build.sh
./scripts/run-qemu.sh
```

Open `dashboard/index.html` in a browser for the MARS project dashboard.

## Optional utilities

```sh
python3 tools/mars_inspect.py .
ruby tools/mars_report.rb .
javac tools/MarsControl.java
java -cp tools MarsControl status
Rscript tools/mars_metrics.R .
```

The Lisp file at `config/mars-config.lisp` is an example configuration
representation; it is not evaluated by the kernel.

## Safety and scope

This is an educational prototype. It does not yet provide paging, a heap,
filesystem, keyboard input, networking, USB, user mode, process isolation,
or a security model. Test only in an emulator until those systems are built.
