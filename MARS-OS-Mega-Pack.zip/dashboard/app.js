const output = document.querySelector("#console");
const status = document.querySelector("#buildStatus");
const lines = [
  "[BOOT] MARS boot sequence requested...",
  "[BOOT] Multiboot entry point ready.",
  "[C]    Initializing kernel core...",
  "[C++]  Starting system service layer...",
  "[MEM]  Memory manager: not implemented yet.",
  "[DEV]  Device drivers: waiting for implementation.",
  "[OK]   MARS educational kernel demo initialized."
];
document.querySelector("#bootBtn").addEventListener("click", () => {
  output.textContent = lines.join("\n");
  status.textContent = "Demo initialized";
});
document.querySelector("#clearBtn").addEventListener("click", () => {
  output.textContent = "Console cleared.\nThis is a browser-side simulation.";
  status.textContent = "Source ready";
});
