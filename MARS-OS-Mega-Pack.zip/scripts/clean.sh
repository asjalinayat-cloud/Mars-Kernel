#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
make clean
echo "Build artifacts removed."
