#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
command -v make >/dev/null 2>&1 || { echo "Error: make is required."; exit 1; }
command -v nasm >/dev/null 2>&1 || { echo "Error: nasm is required."; exit 1; }
command -v i686-elf-gcc >/dev/null 2>&1 || { echo "Error: install the i686-elf cross compiler."; exit 1; }
make clean
make
echo "MARS kernel built: $(pwd)/mars.bin"
