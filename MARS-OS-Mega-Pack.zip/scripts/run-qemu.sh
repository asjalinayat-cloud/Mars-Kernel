#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
[ -f mars.bin ] || { echo "mars.bin not found. Run ./scripts/build.sh first."; exit 1; }
command -v qemu-system-i386 >/dev/null 2>&1 || { echo "Install qemu-system-i386 first."; exit 1; }
exec qemu-system-i386 -kernel mars.bin
