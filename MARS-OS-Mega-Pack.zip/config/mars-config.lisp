;; Example configuration data for a future MARS userspace/config parser.
;; This file is not loaded by the freestanding kernel yet.
(defparameter *mars-config*
  '((system-name . "MARS OS")
    (version . "0.2.0-dev")
    (architecture . "i686")
    (kernel-languages . ("C" "C++"))
    (console . "VGA-text")
    (features . ("boot" "console"))
    (planned . ("interrupts" "paging" "heap" "keyboard" "filesystem"))))

(defun mars-config-value (key)
  (cdr (assoc key *mars-config*)))

(format t "Configured system: ~a~%" (mars-config-value 'system-name))
