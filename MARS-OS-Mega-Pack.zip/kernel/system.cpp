#include "kernel.hpp"
#include "kernel.h"

namespace mars {
    const char* version() { return "0.2.0-dev"; }

    void initialize_services() {
        console_line("[C++]  C++ system service layer initialized.");
        console_line("[C++]  MARS kernel version:");
        console_line(version());
    }
}
