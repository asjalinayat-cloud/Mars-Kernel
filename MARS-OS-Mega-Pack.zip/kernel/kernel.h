#ifndef MARS_KERNEL_H
#define MARS_KERNEL_H
#include <stdint.h>
void console_clear(void);
void console_write(const char* text);
void console_line(const char* text);
#endif
