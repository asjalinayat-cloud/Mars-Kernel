#ifndef MARS_KERNEL_HPP
#define MARS_KERNEL_HPP
namespace mars {
    void initialize_services();
    const char* version();
}
#endif
