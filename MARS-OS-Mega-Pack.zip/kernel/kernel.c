#include "kernel.h"
#include "kernel.hpp"

#define VGA ((volatile uint16_t*)0xB8000)
#define WIDTH 80
#define HEIGHT 25
static unsigned int x = 0, y = 0;
static const uint8_t attribute = 0x0F;

static uint16_t cell(char c) {
    return (uint16_t)c | ((uint16_t)attribute << 8);
}

void console_clear(void) {
    for (unsigned int i = 0; i < WIDTH * HEIGHT; ++i) VGA[i] = cell(' ');
    x = 0; y = 0;
}

void console_write(const char* s) {
    while (*s) {
        char c = *s++;
        if (c == '\n') { x = 0; y = (y + 1) % HEIGHT; continue; }
        VGA[y * WIDTH + x] = cell(c);
        if (++x == WIDTH) { x = 0; y = (y + 1) % HEIGHT; }
    }
}

void console_line(const char* s) {
    console_write(s);
    console_write("\n");
}

void kernel_main(uint32_t magic, uint32_t info) {
    (void)info;
    console_clear();
    console_line("================================================");
    console_line("                 MARS OPERATING SYSTEM           ");
    console_line("================================================");
    console_line("");
    console_line("[C]    Kernel entry point reached.");
    if (magic == 0x2BADB002) console_line("[BOOT] Multiboot v1 loader detected.");
    else console_line("[BOOT] Warning: unexpected boot magic.");
    mars::initialize_services();
    console_line("");
    console_line("MARS is alive. This is an educational kernel prototype.");
    console_line("Next milestones: IDT, timer, keyboard, paging, heap.");
    console_line("");
    console_line("CPU halted. Close or reset the emulator to restart.");
    for (;;) __asm__ volatile ("cli; hlt");
}
