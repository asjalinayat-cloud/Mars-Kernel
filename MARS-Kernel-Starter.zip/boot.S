; NASM, 32-bit Multiboot v1 entry point
BITS 32

section .multiboot
align 4
    dd 0x1BADB002                 ; magic
    dd 0x00000003                 ; page-align modules + memory info
    dd -(0x1BADB002 + 0x00000003) ; checksum

section .bss
align 16
stack_bottom:
    resb 16384
stack_top:

section .text
global _start
extern kernel_main

_start:
    cli
    mov esp, stack_top
    xor ebp, ebp
    push ebx                      ; Multiboot info pointer
    push eax                      ; Multiboot magic
    call kernel_main

.hang:
    cli
    hlt
    jmp .hang
