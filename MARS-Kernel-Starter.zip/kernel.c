#include "kernel.h"
#include "kernel.hpp"

#define VGA_MEMORY ((volatile uint16_t*)0xB8000)
#define VGA_WIDTH 80
#define VGA_HEIGHT 25

static uint8_t row = 0;
static uint8_t column = 0;
static uint8_t color = 0x0F; /* white on black */

static uint16_t vga_entry(char c, uint8_t attribute) {
    return (uint16_t)c | ((uint16_t)attribute << 8);
}

void vga_clear(void) {
    for (int y = 0; y < VGA_HEIGHT; ++y) {
        for (int x = 0; x < VGA_WIDTH; ++x) {
            VGA_MEMORY[y * VGA_WIDTH + x] = vga_entry(' ', color);
        }
    }
    row = 0;
    column = 0;
}

void vga_write(const char* text) {
    while (*text) {
        char c = *text++;
        if (c == '\n') {
            column = 0;
            if (++row >= VGA_HEIGHT) row = 0;
            continue;
        }
        VGA_MEMORY[row * VGA_WIDTH + column] = vga_entry(c, color);
        if (++column >= VGA_WIDTH) {
            column = 0;
            if (++row >= VGA_HEIGHT) row = 0;
        }
    }
}

void vga_write_line(const char* text) {
    vga_write(text);
    vga_write("\n");
}

void kernel_main(uint32_t multiboot_magic, uint32_t multiboot_info) {
    (void)multiboot_info;
    vga_clear();

    vga_write_line("========================================");
    vga_write_line("             MARS OPERATING SYSTEM      ");
    vga_write_line("========================================");
    vga_write_line("");
    vga_write_line("[C]     MARS kernel entry started.");

    if (multiboot_magic == 0x2BADB002) {
        vga_write_line("[BOOT]  Multiboot loader detected.");
    } else {
        vga_write_line("[BOOT]  WARNING: unexpected boot magic.");
    }

    mars::initialize_system();
    vga_write_line("");
    vga_write_line("MARS kernel is running.");
    vga_write_line("Next: add interrupts, memory management,");
    vga_write_line("keyboard input, and a filesystem.");
    vga_write_line("");
    vga_write_line("CPU halted safely. Restart QEMU to boot again.");

    for (;;) {
        __asm__ volatile ("cli; hlt");
    }
}
