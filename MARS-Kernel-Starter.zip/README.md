# MARS Kernel — starter operating-system project

This is a tiny **32-bit x86, BIOS/GRUB Multiboot** kernel starter. It boots into
a VGA text-mode screen and prints messages from both C and C++.

## What is included

- `boot.S`: Multiboot entry point and stack setup (NASM syntax).
- `kernel.c`: freestanding C kernel entry point and VGA text output.
- `kernel.hpp`, `system.cpp`: a small C++ system-services layer.
- `linker.ld`: kernel memory layout.
- `Makefile`: build a Multiboot kernel with an `i686-elf` cross-toolchain.
- `mars-control/`: a C# .NET console launcher that starts the kernel in QEMU.

C and C++ run in the bare-metal kernel. C# is **not** linked into this kernel:
it needs a managed runtime. The included C# program is a host-side launcher.
Running C# inside MARS OS would require porting/including a .NET runtime later.

## Requirements

On a Linux development machine, install:
- `i686-elf-gcc` and `i686-elf-g++` (cross compiler)
- `nasm`
- `make`
- `qemu-system-i386`

A GRUB ISO toolchain is not needed for this starter because QEMU can load a
Multiboot kernel directly with `-kernel`.

## Build

From this directory:

```sh
make
```

This produces `mars.bin`.

## Run

```sh
qemu-system-i386 -kernel mars.bin
```

Or use the C# launcher (requires .NET 8 and QEMU on PATH):

```sh
cd mars-control
dotnet run -- ../mars.bin
```

Press `Ctrl+C` or close QEMU to exit.

## Important limitations

This is an educational bootable kernel skeleton, not a finished operating
system. It currently has no paging, heap allocator, filesystem, keyboard
driver, USB, networking, multitasking, user mode, or security model. It uses
legacy VGA text memory at `0xB8000`, which is suitable for a simple QEMU
BIOS-style demonstration. A production OS needs a much larger architecture.
