using System.Diagnostics;

if (args.Length < 1)
{
    Console.WriteLine("MARS Control Center");
    Console.WriteLine("Usage: dotnet run -- <path-to-mars.bin>");
    return;
}

string kernelPath = Path.GetFullPath(args[0]);
if (!File.Exists(kernelPath))
{
    Console.Error.WriteLine($"Kernel file not found: {kernelPath}");
    Environment.ExitCode = 1;
    return;
}

var startInfo = new ProcessStartInfo
{
    FileName = "qemu-system-i386",
    UseShellExecute = false
};
startInfo.ArgumentList.Add("-kernel");
startInfo.ArgumentList.Add(kernelPath);

try
{
    using Process? qemu = Process.Start(startInfo);
    if (qemu is null)
    {
        Console.Error.WriteLine("Could not start QEMU.");
        Environment.ExitCode = 1;
        return;
    }

    Console.WriteLine("MARS Control Center: QEMU started.");
    Console.WriteLine("Close the QEMU window to stop MARS.");
    await qemu.WaitForExitAsync();
}
catch (Exception ex)
{
    Console.Error.WriteLine($"Could not launch QEMU: {ex.Message}");
    Console.Error.WriteLine("Install qemu-system-i386 and make sure it is on PATH.");
    Environment.ExitCode = 1;
}
