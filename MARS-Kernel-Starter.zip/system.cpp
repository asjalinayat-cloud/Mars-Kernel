#include "kernel.hpp"
#include "kernel.h"

namespace mars {
    void initialize_system() {
        vga_write_line("[C++]   MARS system services initialized.");
        vga_write_line("[C++]   C++ kernel layer is online.");
    }
}
