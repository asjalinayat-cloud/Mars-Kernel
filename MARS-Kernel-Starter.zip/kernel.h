#ifndef MARS_KERNEL_H
#define MARS_KERNEL_H

#include <stdint.h>

void vga_clear(void);
void vga_write(const char* text);
void vga_write_line(const char* text);

#endif
